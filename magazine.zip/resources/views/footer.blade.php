<footer id="fh5co-footer">
		<p><small>&copy; 2016. Magazine Free HTML5. All Rights Reserverd. <br>
		<a href="login">Login / </a><a href="register">Register</a></small></p>
	</footer>



	
	<!-- jQuery -->
	<script src="{{url('assets/js/jquery.min.js')}}"></script>
	<!-- jQuery Easing -->
	<script src="{{url('assets/js/jquery.easing.1.3.js')}}"></script>
	<!-- Bootstrap -->
	<script src="{{url('assets/js/bootstrap.min.js')}}"></script>
	<!-- Waypoints -->
	<script src="{{url('assets/js/jquery.waypoints.min.js')}}"></script>
	<!-- Main JS -->
	<script src="{{url('assets/js/main.js')}}"></script>

	</body>
</html>

