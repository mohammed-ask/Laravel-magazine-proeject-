<html>
    <head>
        <title>
            nothing
        </title>
    </head>
    <body>
        <form action="students" method="post">
           <?php echo csrf_field(); ?>
            <input name="wame" type="text">
            <input name="pass" type="text">
            <input name="word" type="text">
            <input type="submit">
        </form>
    </body>
</html><?php /**PATH C:\Users\Intel\Desktop\blog\resources\views/form.blade.php ENDPATH**/ ?>