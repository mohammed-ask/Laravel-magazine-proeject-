<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(url('assets/summernote/summernote-lite.min.css')); ?>" rel="stylesheet" />
<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- /. NAV TOP  -->
        
        
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2><?php echo e($pagetitle); ?></h2>   
                    </div>
                  
                </div> 
                            
                 <!-- /. ROW  -->
                  <hr />
              <div class="container-fluid col-lg-12">
                      
                       <form action="<?php echo e(url('admin/posts/delete',$old_data['id'])); ?>" method="post" enctype="multipart/form-data" >
                       
                       <div class="form-group row">
                           <label for="title" class="col-sm-2 col-form-label">Post Title</label>
                           <div class="col-sm-10">
                               <input id="title" type="text" class="form-control" value="<?php echo e($old_data['title']); ?>" name="title">
                           </div>
                           <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="error" style="font-size:17px;color:red"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
                       
                       <div class="form-group row">
                           <label for="file" class="col-sm-2 col-form-label">Featured Image</label>
                           <div class="col-sm-10">
                              <img src="<?php echo e(url('upload/'.$old_data['image'])); ?>" style="width:125px" />
                               <input id="file" type="file" class="form-control" name="file">
                           </div>
                           <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="error" style="font-size:17px;color:red"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
                       
                        <?php echo csrf_field(); ?>
                        <textarea id="summernote" name="content" value=""><?php echo e($old_data['content']); ?></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="error" style="font-size:17px;color:red"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <button type="submit" class="btn btn-danger" style="float:right">Delete</button>
                    </form>
                     
                </div> 
                 <!-- /. ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(url('assets/summernote/summernote-lite.min.js')); ?>"></script>
<script>
$(document).ready(function() {
  $('#summernote').summernote({height:400});
});
</script><?php /**PATH C:\xampp\htdocs\magazine\resources\views/admin/delete_post.blade.php ENDPATH**/ ?>