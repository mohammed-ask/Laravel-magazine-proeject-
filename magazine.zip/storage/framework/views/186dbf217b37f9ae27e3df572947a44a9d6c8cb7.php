<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- /. NAV TOP  -->
        
        
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2><?php echo e($pagetitle); ?></h2>   
                    </div>
                  
                </div> 
                            
                 <!-- /. ROW  -->
                  <hr />
              <div>
                    <div>
                    <a href="<?php echo e(url('/register')); ?>" class="" style="float:right">
                        <button class="fa fa-plus btn btn-primary"> Add New User</button>
                    </a>
                  </div>
                     
                          
                        
                     
                      <table class="table table-striped table-hover">
       <thead>
           <tr>
               <th scope="col">Name</th>
               <th scope="col">E-mail</th>
               <th scope="col">Date</th>
               
               <th scope="col">Action</th>
           </tr>
       </thead>
       
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tbody>
           <tr>
              
               <td scope="row"><?php echo e($data2->name); ?></td>
               <td><?php echo e($data2->email); ?></td>
               <td><?php echo e(date("jS M,Y",strtotime($data2->created_at))); ?></td>
              
                <td><a href="<?php echo e(url('/admin/users/edit',$data2->id)); ?>" class="btn-sm btn-primary">Edit</a>|<a class="btn-sm btn-danger" href="<?php echo e(url('/admin/users/delete',$data2->id)); ?>">Delete</a></td>
           </tr>
           
       </tbody>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>

                </div> 
                 <!-- /. ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\magazine\resources\views/admin/user.blade.php ENDPATH**/ ?>