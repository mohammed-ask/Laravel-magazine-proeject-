<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(url('assets/summernote/summernote-lite.min.css')); ?>" rel="stylesheet" />
<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- /. NAV TOP  -->
        
        
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2><?php echo e($pagetitle); ?></h2>   
                    </div>
                  
                </div> 
                            
                 <!-- /. ROW  -->
                  <hr />
              <div>
                    <div>
                    <a href="<?php echo e(url('/admin/posts/add')); ?>" class="" style="float:right">
                        <button class="fa fa-plus btn btn-primary"> Add Post</button>
                    </a>
                  </div>
                     
                          
                        
                     
                      <table class="table table-striped table-hover">
       <thead>
           <tr>
               <th scope="col">Title</th>
               <th scope="col">Content</th>
               <th scope="col">Date</th>
               <th scope="col">Category</th>
               <th scope="col">image</th>
               <th scope="col">Action</th>
           </tr>
       </thead>
       
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tbody>
           <tr>
              
               <td scope="row"><?php echo e($data2->title); ?></td>
               <td><?php echo substr($data2->content,0,400) ?>...</td>
               <td><?php echo e(date("jS M,Y",strtotime($data2->created_at))); ?></td>
               <td><?php echo e($data2->category); ?></td>
               <td><img src="<?php echo e(url('upload/'.$data2->image)); ?>" style="width:125px" /></td>
                <td><a href="<?php echo e(url('/admin/posts/edit',$data2->id)); ?>" class="btn-sm btn-primary">Edit</a>|<a class="btn-sm btn-danger" href="<?php echo e(url('/admin/posts/delete',$data2->id)); ?>">Delete</a></td>
           </tr>
           
       </tbody>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
               <?php echo $__env->make('pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div> 
                 <!-- /. ROW  -->           
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(url('assets/summernote/summernote-lite.min.js')); ?>"></script>
<script>
$(document).ready(function() {
  $('#summernote').summernote();
});
</script><?php /**PATH C:\xampp\htdocs\magazine\resources\views/admin/posts.blade.php ENDPATH**/ ?>