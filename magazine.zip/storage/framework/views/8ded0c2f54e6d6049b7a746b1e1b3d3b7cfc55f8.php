<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
	<!-- END #fh5co-header -->
	<div class="container-fluid">
		<div class="row fh5co-post-entry">
		<?php foreach($row as $rows){ ?>
		    
			<article class="col-lg-3 col-md-3 col-sm-3 col-xs-6 col-xxs-12 animate-box">
				<a href="<?php echo e(url('single/'.$rows->slag)); ?>">
				<figure>
					<img src="<?php echo e(url('upload/'.$rows->image)); ?>" style="height:400px;object-fit:cover" alt="Image" class="img-responsive">
				</figure>
				<span class="fh5co-meta" style="color: #f7c873"><?php echo e($rows->category); ?></span>	
				<h2 class="fh5co-article-title" ><?php echo e($rows->title); ?></h2>
				<span class="fh5co-meta fh5co-date"><?php echo e(date("jS M,Y",strtotime($rows->created_at))); ?></span>
				</a>
			</article>
     
        <?php } ?>
			
			<div class="clearfix visible-xs-block"></div>
		</div>
		
		<?php echo $__env->make('pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php /**PATH C:\xampp\htdocs\magazine\resources\views/index.blade.php ENDPATH**/ ?>